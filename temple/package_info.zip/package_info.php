<?php
include('header.php');
$pnm=$_GET['package'];
$sql="select * from package1 where pname='$pnm'";
$res=mysqli_query($con,$sql);
while($rw=mysqli_fetch_row($res))
{
?>
<div class="container">
    <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
        <h6 class="section-title bg-white text-center text-warning px-3">Packages</h6>
    </div>

    <div>
        <p class="text-center wow fadeInUp" data-wow-delay="0.1s" style="font-size:4rem;font-family:Book Antiqua;color:orange">
            <?php echo $rw[1];?>
        </p>
        <p class="text-center wow fadeInUp" data-wow-delay="0.1s" style="font-size:1.3rem;font-family:Book Antiqua;color:green">
            <?php echo $rw[2];?>/
        </p>
        <p class="text-center wow fadeInUp" data-wow-delay="0.1s" style="font-size:1.5rem;font-family:Book Antiqua;color:red">
            <i class="fa fa-clock"> <?php echo $rw[3]; ?></i>
        </p>

        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="margin-left:250px;margin-right:250px;">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block" src="img/h4.png" alt="First slide" style="height:450px;width:800px;">
                </div>
                <div class="carousel-caption d-none d-md-block">
                    <h5 style="color:white;"><?php echo $rw[1];?></h5>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        
        <p  class=" wow fadeInUp" data-wow-delay="0.1s" style="font-size:3rem;font-family:Book Antiqua;color:orange;">
            Overview
        </p>
        <p style="text-align:justify;margin-right:80px;color:black;margin-left:40px;">
        <?php echo $rw[4];?>
        </p>

        <p class=" wow fadeInUp" data-wow-delay="0.1s" style="font-size:3rem;font-family:Book Antiqua;color:orange">
            Hightlights
        </p>
        <p style="text-align:justify;margin-right:80px;color:black;">
        <div class="div4">
            <i class="fa fa-check"></i> <?php echo $rw[5]; ?><br>
        </div>
        </p>

        <p class=" wow fadeInUp" data-wow-delay="0.1s" style="font-size:3rem;font-family:Book Antiqua;color:orange">
            Itinerary
        </p>
        <p style="text-align:justify;margin-right:80px;color:black;">
            <?php echo $rw[6];?>
        </p>
        <!--
        <div class="details1">
            <details>
                <summary>
                    Day 1
                </summary>
                <p>
                </p>
            </details>
        </div>
        -->
    </div>
</div>
<?php
}
?>
<?php
include('footer.php');
?>